// SPDX-License-Identifier: Apache-2.0 AND MIT

#include <openssl/core_names.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/provider.h>

#include "oqs/oqs.h"
#include "test_common.h"

static OSSL_LIB_CTX *libctx = NULL;
static char *modulename = NULL;
static char *configfile = NULL;
static char *cert = NULL;
static char *privkey = NULL;
static char *certsdir = NULL;
static char *srpvfile = NULL;
static char *tmpfilename = NULL;

// sign-and-hash must work with and without providing a digest algorithm
static int test_oqs_signatures(const char *sigalg_name) {
    EVP_MD_CTX *mdctx = NULL;
    EVP_PKEY_CTX *ctx = NULL;
    EVP_PKEY *key = NULL;
#if (OPENSSL_VERSION_PREREQ(3, 4))
    EVP_PKEY_CTX *pctx = NULL;
    EVP_SIGNATURE *alg = NULL;
#endif
    const char msg[] = "The quick brown fox jumps over... you know what";
    unsigned char *sig;
    size_t siglen;

    int testresult = 1;

    if (!alg_is_enabled(sigalg_name)) {
        fprintf(stderr, "Not testing disabled algorithm %s.\n", sigalg_name);
        return 1;
    }
    // test with built-in digest only if default provider is active:
    // TBD revisit when hybrids are activated: They always need default
    // provider
    if (OSSL_PROVIDER_available(libctx, "default")) {
        testresult &=
            (ctx = EVP_PKEY_CTX_new_from_name(libctx, sigalg_name,
                                              OQSPROV_PROPQ)) != NULL &&
            EVP_PKEY_keygen_init(ctx) && EVP_PKEY_generate(ctx, &key) &&
            (mdctx = EVP_MD_CTX_new()) != NULL &&
            EVP_DigestSignInit_ex(mdctx, NULL, "SHA512", libctx, NULL, key,
                                  NULL) &&
            EVP_DigestSignUpdate(mdctx, msg, sizeof(msg)) &&
            EVP_DigestSignFinal(mdctx, NULL, &siglen) &&
            (sig = OPENSSL_malloc(siglen)) != NULL &&
            EVP_DigestSignFinal(mdctx, sig, &siglen) &&
            EVP_DigestVerifyInit_ex(mdctx, NULL, "SHA512", libctx, NULL, key,
                                    NULL) &&
            EVP_DigestVerifyUpdate(mdctx, msg, sizeof(msg)) &&
            EVP_DigestVerifyFinal(mdctx, sig, siglen);
        sig[0] = ~sig[0];
        testresult &= EVP_DigestVerifyInit_ex(mdctx, NULL, "SHA512", libctx,
                                              NULL, key, NULL) &&
                      EVP_DigestVerifyUpdate(mdctx, msg, sizeof(msg)) &&
                      !EVP_DigestVerifyFinal(mdctx, sig, siglen);
    }

    EVP_MD_CTX_free(mdctx);
    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(ctx);
    OPENSSL_free(sig);
    mdctx = NULL;
    key = NULL;

    // this test must work also with default provider inactive:
    testresult &=
        (ctx = EVP_PKEY_CTX_new_from_name(libctx, sigalg_name,
                                          OQSPROV_PROPQ)) != NULL &&
        EVP_PKEY_keygen_init(ctx) && EVP_PKEY_generate(ctx, &key) &&
        (mdctx = EVP_MD_CTX_new()) != NULL &&
        EVP_DigestSignInit_ex(mdctx, NULL, NULL, libctx, NULL, key, NULL) &&
        EVP_DigestSignUpdate(mdctx, msg, sizeof(msg)) &&
        EVP_DigestSignFinal(mdctx, NULL, &siglen) &&
        (sig = OPENSSL_malloc(siglen)) != NULL &&
        EVP_DigestSignFinal(mdctx, sig, &siglen) &&
        EVP_DigestVerifyInit_ex(mdctx, NULL, NULL, libctx, NULL, key, NULL) &&
        EVP_DigestVerifyUpdate(mdctx, msg, sizeof(msg)) &&
        EVP_DigestVerifyFinal(mdctx, sig, siglen);
    sig[0] = ~sig[0];
    testresult &=
        EVP_DigestVerifyInit_ex(mdctx, NULL, NULL, libctx, NULL, key, NULL) &&
        EVP_DigestVerifyUpdate(mdctx, msg, sizeof(msg)) &&
        !EVP_DigestVerifyFinal(mdctx, sig, siglen);

    EVP_MD_CTX_free(mdctx);
    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(ctx);
    OPENSSL_free(sig);
#if (OPENSSL_VERSION_PREREQ(3, 4))
    key = NULL;
    testresult &=
        (ctx = EVP_PKEY_CTX_new_from_name(libctx, sigalg_name,
                                          OQSPROV_PROPQ)) != NULL &&
        EVP_PKEY_keygen_init(ctx) && EVP_PKEY_generate(ctx, &key) &&
        (alg = EVP_SIGNATURE_fetch(libctx, sigalg_name, OQSPROV_PROPQ)) !=
            NULL &&
        (pctx = EVP_PKEY_CTX_new_from_pkey(libctx, key, OQSPROV_PROPQ)) !=
            NULL &&
        EVP_PKEY_sign_message_init(pctx, alg, NULL) &&
        EVP_PKEY_sign(pctx, NULL, &siglen, (const unsigned char *)msg,
                      sizeof(msg)) &&
        (sig = OPENSSL_malloc(siglen)) != NULL &&
        EVP_PKEY_sign(pctx, sig, &siglen, (const unsigned char *)msg,
                      sizeof(msg)) &&
        EVP_PKEY_verify_message_init(pctx, alg, NULL) &&
        EVP_PKEY_verify(pctx, sig, siglen, (const unsigned char *)msg,
                        sizeof(msg));
    sig[0] = ~sig[0];
    testresult &= EVP_PKEY_verify_message_init(pctx, alg, NULL) &&
                  !EVP_PKEY_verify(pctx, sig, siglen,
                                   (const unsigned char *)msg, sizeof(msg));

    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(ctx);
    EVP_PKEY_CTX_free(pctx);
    OPENSSL_free(sig);
    key = NULL;

    testresult &= (ctx = EVP_PKEY_CTX_new_from_name(libctx, sigalg_name,
                                                    OQSPROV_PROPQ)) != NULL &&
                  EVP_PKEY_keygen_init(ctx) && EVP_PKEY_generate(ctx, &key) &&
                  (pctx = EVP_PKEY_CTX_new_from_pkey(libctx, key,
                                                     OQSPROV_PROPQ)) != NULL &&
                  EVP_PKEY_sign_message_init(pctx, alg, NULL) &&
                  EVP_PKEY_sign(pctx, NULL, &siglen, (const unsigned char *)msg,
                                sizeof(msg)) &&
                  (sig = OPENSSL_malloc(siglen)) != NULL &&
                  EVP_PKEY_sign(pctx, sig, &siglen, (const unsigned char *)msg,
                                sizeof(msg)) &&
                  EVP_PKEY_verify_message_init(pctx, alg, NULL) &&
                  EVP_PKEY_verify(pctx, sig, siglen, (const unsigned char *)msg,
                                  sizeof(msg));
    sig[0] = ~sig[0];
    testresult &= EVP_PKEY_verify_message_init(pctx, alg, NULL) &&
                  !EVP_PKEY_verify(pctx, sig, siglen,
                                   (const unsigned char *)msg, sizeof(msg));

    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(ctx);
    EVP_PKEY_CTX_free(pctx);
    OPENSSL_free(sig);
    key = NULL;

    testresult &=
        (ctx = EVP_PKEY_CTX_new_from_name(libctx, sigalg_name,
                                          OQSPROV_PROPQ)) != NULL &&
        EVP_PKEY_keygen_init(ctx) && EVP_PKEY_generate(ctx, &key) &&
        (pctx = EVP_PKEY_CTX_new_from_pkey(libctx, key, OQSPROV_PROPQ)) !=
            NULL &&
        EVP_PKEY_sign_message_init(pctx, alg, NULL) &&
        EVP_PKEY_sign_message_update(pctx, (const unsigned char *)msg,
                                     sizeof(msg)) &&
        EVP_PKEY_sign_message_final(pctx, NULL, &siglen) &&
        (sig = OPENSSL_malloc(siglen)) != NULL &&
        EVP_PKEY_sign_message_final(pctx, sig, &siglen) &&
        EVP_PKEY_verify_message_init(pctx, alg, NULL) &&
        EVP_PKEY_CTX_set_signature(pctx, sig, siglen) &&
        EVP_PKEY_verify_message_update(pctx, (const unsigned char *)msg,
                                       sizeof(msg)) &&
        EVP_PKEY_verify_message_final(pctx);
    sig[0] = ~sig[0];
    testresult &= EVP_PKEY_verify_message_init(pctx, alg, NULL) &&
                  EVP_PKEY_CTX_set_signature(pctx, sig, siglen) &&
                  EVP_PKEY_verify_message_update(
                      pctx, (const unsigned char *)msg, sizeof(msg)) &&
                  !EVP_PKEY_verify_message_final(pctx);

    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(ctx);
    EVP_PKEY_CTX_free(pctx);
    EVP_SIGNATURE_free(alg);
    OPENSSL_free(sig);
#endif
    return testresult;
}

static int test_oqs_signatures_with_ctx_str(const char *sigalg_name) {
    EVP_MD_CTX *mdctx = NULL;
    EVP_PKEY_CTX *ctx = NULL, *pctx = NULL;
    EVP_PKEY *key = NULL;
    OSSL_PARAM params[2] = {OSSL_PARAM_END, OSSL_PARAM_END};
    const char msg[] = "The quick brown fox jumps over... you know what";
    const char ctx_str[] = "Use a non-null context string";
    unsigned char *sig;
    size_t siglen;

    int testresult = 1;

    if (!alg_is_enabled(sigalg_name)) {
        fprintf(stderr, "Not testing disabled algorithm %s.\n", sigalg_name);
        return 1;
    }
#if (OPENSSL_VERSION_PREREQ(3, 2) &&                                           \
     (defined OQS_VERSION_MINOR &&                                             \
      (OQS_VERSION_MAJOR > 0 || OQS_VERSION_MINOR >= 14)))
    params[0] = OSSL_PARAM_construct_octet_string(
        OSSL_SIGNATURE_PARAM_CONTEXT_STRING, (void *)ctx_str, sizeof(ctx_str));

    testresult &=
        (ctx = EVP_PKEY_CTX_new_from_name(libctx, sigalg_name,
                                          OQSPROV_PROPQ)) != NULL &&
        EVP_PKEY_keygen_init(ctx) && EVP_PKEY_generate(ctx, &key) &&
        (mdctx = EVP_MD_CTX_new()) != NULL &&
        EVP_DigestSignInit_ex(mdctx, &pctx, NULL, libctx, NULL, key, NULL) &&
        EVP_PKEY_CTX_set_params(pctx, params) &&
        EVP_DigestSignUpdate(mdctx, msg, sizeof(msg)) &&
        EVP_DigestSignFinal(mdctx, NULL, &siglen) &&
        (sig = OPENSSL_malloc(siglen)) != NULL &&
        EVP_DigestSignFinal(mdctx, sig, &siglen) &&
        EVP_DigestVerifyInit_ex(mdctx, &pctx, NULL, libctx, NULL, key, NULL) &&
        EVP_PKEY_CTX_set_params(pctx, params) &&
        EVP_DigestVerifyUpdate(mdctx, msg, sizeof(msg)) &&
        EVP_DigestVerifyFinal(mdctx, sig, siglen);

    testresult =
        testresult == does_signature_algorithm_support_ctx_str(sigalg_name);

    EVP_MD_CTX_free(mdctx);
    EVP_PKEY_free(key);
    EVP_PKEY_CTX_free(ctx);
    OPENSSL_free(sig);
#endif
    return testresult;
}

/* Regression test for GHSA-2gh6-p878-65cq: double-free of ctx->signature
 * when a signature context with a populated 'signature' field is duplicated
 * and both copies are freed. */
static int test_oqs_sig_dupctx_double_free(const char *sigalg_name) {
#if (OPENSSL_VERSION_PREREQ(3, 4))
    EVP_PKEY_CTX *ctx = NULL, *pctx = NULL, *pctx_dup = NULL;
    EVP_PKEY *key = NULL;
    EVP_SIGNATURE *alg = NULL;
    EVP_MD_CTX *mdctx = NULL, *mdctx_dup = NULL;
    EVP_PKEY_CTX *dvpctx = NULL;
    const char msg[] = "The quick brown fox jumps over... you know what";
    unsigned char *sig = NULL;
    size_t siglen;
    int testresult = 0;

    if (!alg_is_enabled(sigalg_name)) {
        fprintf(stderr, "Not testing disabled algorithm %s.\n", sigalg_name);
        return 1;
    }

    /* Generate a key and produce a valid signature */
    if (!(ctx =
              EVP_PKEY_CTX_new_from_name(libctx, sigalg_name, OQSPROV_PROPQ)) ||
        !EVP_PKEY_keygen_init(ctx) || !EVP_PKEY_generate(ctx, &key) ||
        !(alg = EVP_SIGNATURE_fetch(libctx, sigalg_name, OQSPROV_PROPQ)) ||
        !(pctx = EVP_PKEY_CTX_new_from_pkey(libctx, key, OQSPROV_PROPQ)) ||
        !EVP_PKEY_sign_message_init(pctx, alg, NULL) ||
        !EVP_PKEY_sign(pctx, NULL, &siglen, (const unsigned char *)msg,
                       sizeof(msg)) ||
        !(sig = OPENSSL_malloc(siglen)) ||
        !EVP_PKEY_sign(pctx, sig, &siglen, (const unsigned char *)msg,
                       sizeof(msg)))
        goto err;

    /* Test 1: EVP_PKEY_CTX_dup after EVP_PKEY_CTX_set_signature.
     * Populate ctx->signature via verify_message_init + set_signature,
     * then duplicate the context and free both copies. */
    if (!EVP_PKEY_verify_message_init(pctx, alg, NULL) ||
        !EVP_PKEY_CTX_set_signature(pctx, sig, siglen) ||
        !(pctx_dup = EVP_PKEY_CTX_dup(pctx)))
        goto err;

    EVP_PKEY_CTX_free(pctx_dup);
    pctx_dup = NULL;
    EVP_PKEY_CTX_free(pctx);
    pctx = NULL;

    /* Test 2: EVP_MD_CTX_copy_ex with DigestVerify.
     * The internal EVP_PKEY_CTX is duplicated via the provider's dupctx. */
    if (!(mdctx = EVP_MD_CTX_new()) ||
        !EVP_DigestVerifyInit_ex(mdctx, &dvpctx, NULL, libctx, NULL, key,
                                 NULL) ||
        !EVP_PKEY_CTX_set_signature(dvpctx, sig, siglen) ||
        !(mdctx_dup = EVP_MD_CTX_new()) ||
        !EVP_MD_CTX_copy_ex(mdctx_dup, mdctx))
        goto err;

    EVP_MD_CTX_free(mdctx_dup);
    mdctx_dup = NULL;
    EVP_MD_CTX_free(mdctx);
    mdctx = NULL;

    testresult = 1;

err:
    EVP_PKEY_CTX_free(pctx_dup);
    EVP_PKEY_CTX_free(pctx);
    EVP_MD_CTX_free(mdctx_dup);
    EVP_MD_CTX_free(mdctx);
    EVP_PKEY_CTX_free(ctx);
    EVP_SIGNATURE_free(alg);
    EVP_PKEY_free(key);
    OPENSSL_free(sig);
    return testresult;
#else
    (void)sigalg_name;
    return 1;
#endif
}

#define nelem(a) (sizeof(a) / sizeof((a)[0]))

int main(int argc, char *argv[]) {
    size_t i;
    int errcnt = 0, test = 0, query_nocache;
    OSSL_PROVIDER *oqsprov = NULL;
    const OSSL_ALGORITHM *sigalgs;

    T((libctx = OSSL_LIB_CTX_new()) != NULL);
    T(argc == 3);
    modulename = argv[1];
    configfile = argv[2];

    load_oqs_provider(libctx, modulename, configfile);

    oqsprov = OSSL_PROVIDER_load(libctx, modulename);

    sigalgs = OSSL_PROVIDER_query_operation(oqsprov, OSSL_OP_SIGNATURE,
                                            &query_nocache);
    if (sigalgs) {
        for (; sigalgs->algorithm_names != NULL; sigalgs++) {
            if (test_oqs_signatures(sigalgs->algorithm_names) &&
                test_oqs_signatures_with_ctx_str(sigalgs->algorithm_names) &&
                test_oqs_sig_dupctx_double_free(sigalgs->algorithm_names)) {
                fprintf(stderr,
                        cGREEN "  Signature test succeeded: %s" cNORM "\n",
                        sigalgs->algorithm_names);
            } else {
                fprintf(stderr, cRED "  Signature test failed: %s" cNORM "\n",
                        sigalgs->algorithm_names);
                ERR_print_errors_fp(stderr);
                errcnt++;
            }
        }
    }

    OSSL_PROVIDER_unload(oqsprov);
    OSSL_LIB_CTX_free(libctx);

    TEST_ASSERT(errcnt == 0)
    return !test;
}
